package com.example.backorder.controller;

import com.example.backorder.controller.Dtos.PlaceOrderRequest;
import com.example.backorder.model.BackorderEntry;
import com.example.backorder.model.Order;
import com.example.backorder.service.BackorderService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/orders")
@RequiredArgsConstructor
public class OrderController {

    private final BackorderService backorderService;

    /**
     * Place an order. If stock is available, it's fulfilled immediately.
     * If not, it enters the backorder queue with the specified strategy.
     */
    @PostMapping
    public ResponseEntity<Order> placeOrder(@Valid @RequestBody PlaceOrderRequest request) {
        Order order = backorderService.placeOrder(
                request.getCustomerId(),
                request.getProductId(),
                request.getQuantity(),
                request.getStrategy(),
                request.getPriorityScore(),
                request.isAllowsPartialFulfillment()
        );
        return ResponseEntity.ok(order);
    }

    /** Cancel an order and release its backorder entries. */
    @DeleteMapping("/{orderId}")
    public ResponseEntity<Map<String, String>> cancelOrder(@PathVariable Long orderId) {
        backorderService.cancelOrder(orderId);
        return ResponseEntity.ok(Map.of("status", "cancelled", "orderId", orderId.toString()));
    }

    /** Get all backorder entries for an order. */
    @GetMapping("/{orderId}/backorders")
    public ResponseEntity<List<BackorderEntry>> getBackordersForOrder(@PathVariable Long orderId) {
        return ResponseEntity.ok(backorderService.getEntriesForOrder(orderId));
    }
}
