package com.example.backorder.job;

import com.example.backorder.model.BackorderStatus;
import com.example.backorder.repository.BackorderEntryRepository;
import com.example.backorder.repository.OrderRepository;
import com.example.backorder.service.NotificationService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.time.temporal.ChronoUnit;

/**
 * Daily sweep that detects backorders waiting longer than the configured threshold
 * and proactively notifies customers with a cancellation option.
 */
@Component
@Slf4j
@RequiredArgsConstructor
public class StaleBackorderSweepJob {

    private final BackorderEntryRepository backorderEntryRepository;
    private final OrderRepository orderRepository;
    private final NotificationService notificationService;

    @Value("${app.backorder.stale-threshold-days}")
    private int staleThresholdDays;

    @Scheduled(cron = "0 0 9 * * *")  // every day at 9 AM
    public void sweepStaleBackorders() {
        Instant threshold = Instant.now().minus(staleThresholdDays, ChronoUnit.DAYS);
        log.info("Sweeping backorders older than {} days (before {})", staleThresholdDays, threshold);

        backorderEntryRepository.findAll().stream()
                .filter(e -> e.getStatus() == BackorderStatus.WAITING)
                .filter(e -> e.getCreatedAt().isBefore(threshold))
                .forEach(entry ->
                    orderRepository.findById(entry.getOrderId()).ifPresent(order ->
                        notificationService.notifyStaleBackorder(order, entry)
                    )
                );
    }
}
