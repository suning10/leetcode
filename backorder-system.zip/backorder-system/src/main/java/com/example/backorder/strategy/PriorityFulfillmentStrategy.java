package com.example.backorder.strategy;

import com.example.backorder.model.BackorderEntry;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * Priority strategy: processes the queue in priority-score order (already sorted by the
 * repository query). Unlike strict FIFO, this strategy SKIPS entries it cannot fully
 * satisfy and continues to lower-priority entries that fit in remaining stock.
 *
 * Use case: VIP/flash-sale scenarios where high-value orders should be served first,
 * and smaller orders behind them shouldn't be blocked by a large order ahead.
 */
@Component("PRIORITY")
public class PriorityFulfillmentStrategy implements FulfillmentStrategy {

    @Override
    public List<Allocation> allocate(List<BackorderEntry> queue, int availableStock) {
        List<Allocation> allocations = new ArrayList<>();

        for (BackorderEntry entry : queue) {
            if (availableStock <= 0) break;

            int needed = entry.quantityRemaining();
            if (availableStock >= needed) {
                allocations.add(new Allocation(entry, needed));
                availableStock -= needed;
            } else if (entry.isAllowsPartialFulfillment()) {
                allocations.add(new Allocation(entry, availableStock));
                availableStock = 0;
            }
            // else: skip this entry, try the next one (key difference from FIFO)
        }

        return allocations;
    }
}
