package com.example.backorder.strategy;

import com.example.backorder.model.BackorderEntry;
import lombok.Value;

/**
 * Immutable decision: allocate {@code quantity} units to {@code entry}.
 */
@Value
public class Allocation {
    BackorderEntry entry;
    int quantity;
}
