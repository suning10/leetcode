package com.example.backorder.model;

public enum BackorderStatus {
    WAITING,
    ALLOCATED,        // fully satisfied
    PARTIALLY_FULFILLED,
    CANCELLED
}
