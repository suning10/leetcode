package com.example.backorder.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.Instant;

/**
 * One line in the backorder queue: a specific product+quantity for a specific order.
 * An order may have multiple BackorderEntry rows (one per backordered product).
 */
@Entity
@Table(name = "backorder_entries",
        indexes = {
            @Index(name = "idx_be_product_status", columnList = "productId, status"),
            @Index(name = "idx_be_order", columnList = "orderId")
        })
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class BackorderEntry {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private Long orderId;

    @Column(nullable = false)
    private Long productId;

    @Column(nullable = false)
    private int quantityRequested;

    @Column(nullable = false)
    private int quantityFulfilled;   // incremented on partial/full allocation

    /**
     * Composite sort key:
     *   - Higher value = higher priority (floats to front)
     *   - Default 0 for standard FIFO orders
     *   - VIP / flash-sale orders get a positive score at creation time
     */
    @Column(nullable = false)
    private int priorityScore;

    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    private FulfillmentStrategyType fulfillmentStrategy;

    @Column(nullable = false)
    private boolean allowsPartialFulfillment;

    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    private BackorderStatus status;

    @Column(nullable = false)
    private Instant createdAt;

    private Instant updatedAt;

    @PrePersist
    void onCreate() {
        createdAt = Instant.now();
        updatedAt = Instant.now();
        if (status == null) status = BackorderStatus.WAITING;
    }

    @PreUpdate
    void onUpdate() {
        updatedAt = Instant.now();
    }

    public int quantityRemaining() {
        return quantityRequested - quantityFulfilled;
    }
}
