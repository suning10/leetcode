package com.example.backorder;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class BackorderApplication {
    public static void main(String[] args) {
        SpringApplication.run(BackorderApplication.class, args);
    }
}
