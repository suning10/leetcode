package com.example.backorder.model;

public enum OrderStatus {
    PENDING,
    BACKORDERED,
    PARTIALLY_FULFILLED,
    FULFILLED,
    CANCELLED
}
