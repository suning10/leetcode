package com.example.backorder.service;

import com.example.backorder.event.InventoryRestockedEvent;
import com.example.backorder.model.Product;
import com.example.backorder.repository.ProductRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.List;

/**
 * Syncs inventory from the upstream source (stubbed here as a no-op that you replace
 * with your real warehouse/ERP API call).
 *
 * Both the @Scheduled hourly run and the manual REST trigger call syncAll(),
 * ensuring identical behaviour regardless of how the sync was initiated.
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class InventorySyncService {

    private final ProductRepository productRepository;
    private final ApplicationEventPublisher eventPublisher;

    /** Runs every hour on the hour (configurable via app.inventory.sync-cron). */
    @Scheduled(cron = "${app.inventory.sync-cron}")
    public void scheduledSync() {
        log.info("Hourly inventory sync triggered at {}", Instant.now());
        syncAll();
    }

    /** Called by the REST endpoint for a manual sync. */
    public void manualSync() {
        log.info("Manual inventory sync triggered at {}", Instant.now());
        syncAll();
    }

    /** Sync a single product by ID (targeted manual trigger). */
    @Transactional
    public void syncProduct(Long productId) {
        productRepository.findById(productId).ifPresent(product -> {
            log.info("Targeted sync for productId={}", productId);
            syncSingleProduct(product);
        });
    }

    @Transactional
    public void syncAll() {
        List<Product> products = productRepository.findAll();
        log.info("Syncing {} products", products.size());
        products.forEach(this::syncSingleProduct);
    }

    /**
     * Fetches the latest stock level from the upstream source and compares it
     * against what we have. If stock has increased, publishes an event so the
     * allocation job can process any waiting backorders.
     *
     * TODO: Replace fetchUpstreamStock() with your real ERP/warehouse API call.
     */
    private void syncSingleProduct(Product product) {
        int previousStock = product.getAvailableStock();
        int upstreamStock = fetchUpstreamStock(product.getSku());

        product.setAvailableStock(upstreamStock);
        product.setLastSyncedAt(Instant.now());
        productRepository.save(product);

        if (upstreamStock > previousStock) {
            log.info("Stock increase detected for sku={}: {} -> {}", product.getSku(), previousStock, upstreamStock);
            eventPublisher.publishEvent(
                    new InventoryRestockedEvent(this, product.getId(), previousStock, upstreamStock));
        } else {
            log.debug("No stock increase for sku={} (upstream={}, local={})",
                    product.getSku(), upstreamStock, previousStock);
        }
    }

    /**
     * STUB — replace with your real upstream call.
     * e.g. warehouseApiClient.getStock(sku)
     */
    private int fetchUpstreamStock(String sku) {
        // Simulates a remote call by returning current DB value unchanged.
        // Your real implementation would call an external API here.
        return productRepository.findBySku(sku)
                .map(Product::getAvailableStock)
                .orElse(0);
    }
}
