package com.example.backorder.service;

import com.example.backorder.model.BackorderEntry;
import com.example.backorder.model.Order;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

/**
 * Stub notification service. Replace the log statements with your real
 * email/SMS/push provider (SendGrid, Twilio, FCM, etc.).
 */
@Service
@Slf4j
public class NotificationService {

    public void notifyBackordered(Order order, BackorderEntry entry) {
        log.info("[NOTIFY] Customer {} — order #{} is BACKORDERED for product {} (qty: {})",
                order.getCustomerId(), order.getId(), entry.getProductId(), entry.getQuantityRequested());
    }

    public void notifyPartiallyFulfilled(Order order, BackorderEntry entry, int quantityShipped) {
        log.info("[NOTIFY] Customer {} — order #{} PARTIALLY FULFILLED: {} of {} units shipped for product {}",
                order.getCustomerId(), order.getId(), quantityShipped,
                entry.getQuantityRequested(), entry.getProductId());
    }

    public void notifyFulfilled(Order order, BackorderEntry entry) {
        log.info("[NOTIFY] Customer {} — order #{} FULFILLED for product {} (qty: {})",
                order.getCustomerId(), order.getId(), entry.getProductId(), entry.getQuantityRequested());
    }

    public void notifyCancelled(Order order, BackorderEntry entry) {
        log.info("[NOTIFY] Customer {} — order #{} CANCELLED for product {}",
                order.getCustomerId(), order.getId(), entry.getProductId());
    }

    public void notifyStaleBackorder(Order order, BackorderEntry entry) {
        log.info("[NOTIFY] Customer {} — order #{} has been waiting {} days for product {}. Offering cancellation option.",
                order.getCustomerId(), order.getId(),
                java.time.Duration.between(entry.getCreatedAt(), java.time.Instant.now()).toDays(),
                entry.getProductId());
    }
}
