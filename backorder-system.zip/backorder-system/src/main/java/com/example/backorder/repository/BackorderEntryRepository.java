package com.example.backorder.repository;

import com.example.backorder.model.BackorderEntry;
import com.example.backorder.model.BackorderStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface BackorderEntryRepository extends JpaRepository<BackorderEntry, Long> {

    /**
     * Fetch the active backorder queue for a product.
     * Sorted by priorityScore DESC (higher = more urgent), then createdAt ASC (FIFO tiebreak).
     */
    @Query("""
        SELECT b FROM BackorderEntry b
        WHERE b.productId = :productId
          AND b.status IN ('WAITING', 'PARTIALLY_FULFILLED')
        ORDER BY b.priorityScore DESC, b.createdAt ASC
        """)
    List<BackorderEntry> findActiveQueueForProduct(Long productId);

    List<BackorderEntry> findByOrderId(Long orderId);

    List<BackorderEntry> findByOrderIdAndStatus(Long orderId, BackorderStatus status);
}
