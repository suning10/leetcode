package com.example.backorder.service;

import com.example.backorder.model.*;
import com.example.backorder.repository.BackorderEntryRepository;
import com.example.backorder.repository.OrderRepository;
import com.example.backorder.repository.ProductRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Slf4j
@RequiredArgsConstructor
public class BackorderService {

    private final BackorderEntryRepository backorderEntryRepository;
    private final OrderRepository orderRepository;
    private final ProductRepository productRepository;
    private final NotificationService notificationService;

    /**
     * Places a new order and immediately enqueues a backorder entry if stock is insufficient.
     * If stock is sufficient, allocates directly and marks order FULFILLED.
     */
    @Transactional
    public Order placeOrder(String customerId, Long productId, int quantity,
                            FulfillmentStrategyType strategy, int priorityScore,
                            boolean allowsPartial) {

        Product product = productRepository.findByIdForUpdate(productId)
                .orElseThrow(() -> new IllegalArgumentException("Product not found: " + productId));

        Order order = orderRepository.save(Order.builder()
                .customerId(customerId)
                .status(OrderStatus.PENDING)
                .build());

        if (product.getAvailableStock() >= quantity) {
            // Enough stock — fulfill immediately
            product.setAvailableStock(product.getAvailableStock() - quantity);
            productRepository.save(product);
            order.setStatus(OrderStatus.FULFILLED);
            orderRepository.save(order);
            log.info("Order #{} fulfilled immediately (stock sufficient)", order.getId());
        } else {
            // Insufficient stock — enter backorder queue
            BackorderEntry entry = BackorderEntry.builder()
                    .orderId(order.getId())
                    .productId(productId)
                    .quantityRequested(quantity)
                    .quantityFulfilled(0)
                    .priorityScore(priorityScore)
                    .fulfillmentStrategy(strategy != null ? strategy : product.getDefaultStrategy())
                    .allowsPartialFulfillment(allowsPartial)
                    .status(BackorderStatus.WAITING)
                    .build();

            backorderEntryRepository.save(entry);
            order.setStatus(OrderStatus.BACKORDERED);
            orderRepository.save(order);

            notificationService.notifyBackordered(order, entry);
            log.info("Order #{} entered backorder queue for productId={}", order.getId(), productId);
        }

        return order;
    }

    /**
     * Cancels all waiting backorder entries for an order and releases any reserved stock.
     */
    @Transactional
    public void cancelOrder(Long orderId) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new IllegalArgumentException("Order not found: " + orderId));

        if (order.getStatus() == OrderStatus.CANCELLED) {
            log.warn("Order #{} is already cancelled", orderId);
            return;
        }

        List<BackorderEntry> activeEntries = backorderEntryRepository
                .findByOrderIdAndStatus(orderId, BackorderStatus.WAITING);

        activeEntries.forEach(entry -> {
            entry.setStatus(BackorderStatus.CANCELLED);
            backorderEntryRepository.save(entry);
            notificationService.notifyCancelled(order, entry);
        });

        order.setStatus(OrderStatus.CANCELLED);
        orderRepository.save(order);
        log.info("Order #{} cancelled. {} backorder entries released.", orderId, activeEntries.size());
    }

    /** Returns all backorder entries currently waiting for a product. */
    public List<BackorderEntry> getQueueForProduct(Long productId) {
        return backorderEntryRepository.findActiveQueueForProduct(productId);
    }

    /** Returns all backorder entries for a specific order. */
    public List<BackorderEntry> getEntriesForOrder(Long orderId) {
        return backorderEntryRepository.findByOrderId(orderId);
    }
}
