package com.example.backorder.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.Instant;

@Entity
@Table(name = "products")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Product {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String sku;

    @Column(nullable = false)
    private String name;

    /** Available (unreserved) units */
    @Column(nullable = false)
    private int availableStock;

    /** Whether orders for this product may be partially fulfilled */
    @Column(nullable = false)
    private boolean allowsPartialFulfillment;

    @Column(nullable = false)
    @Enumerated(EnumType.STRING)
    private FulfillmentStrategyType defaultStrategy;

    private Instant lastSyncedAt;
}
