package com.example.backorder.strategy;

import com.example.backorder.model.BackorderEntry;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * Partial fulfillment strategy: every entry in the queue gets as much as possible,
 * in FIFO order. Never skips an entry — spreads available stock across all waiting orders
 * proportionally if needed (first-come-first-served for partial units).
 *
 * Use case: B2B scenarios where shipping partial quantities immediately is preferred
 * over waiting for full stock.
 */
@Component("PARTIAL")
public class PartialFulfillmentStrategy implements FulfillmentStrategy {

    @Override
    public List<Allocation> allocate(List<BackorderEntry> queue, int availableStock) {
        List<Allocation> allocations = new ArrayList<>();

        for (BackorderEntry entry : queue) {
            if (availableStock <= 0) break;

            int needed = entry.quantityRemaining();
            int toAllocate = Math.min(needed, availableStock);
            allocations.add(new Allocation(entry, toAllocate));
            availableStock -= toAllocate;
        }

        return allocations;
    }
}
