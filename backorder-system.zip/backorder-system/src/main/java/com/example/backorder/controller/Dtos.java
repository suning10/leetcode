package com.example.backorder.controller;

import com.example.backorder.model.FulfillmentStrategyType;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

public class Dtos {

    @Data
    public static class PlaceOrderRequest {
        @NotBlank
        public String customerId;

        @NotNull
        public Long productId;

        @Min(1)
        public int quantity;

        /** Optional — defaults to product's defaultStrategy if null */
        public FulfillmentStrategyType strategy;

        /** 0 = standard, positive = elevated priority */
        public int priorityScore = 0;

        public boolean allowsPartialFulfillment = false;
    }

    @Data
    public static class RestockRequest {
        @NotNull
        public Long productId;

        @Min(0)
        public int newStock;
    }

    @Data
    public static class CreateProductRequest {
        @NotBlank
        public String sku;

        @NotBlank
        public String name;

        @Min(0)
        public int initialStock;

        public boolean allowsPartialFulfillment = false;

        public FulfillmentStrategyType defaultStrategy = FulfillmentStrategyType.FIFO;
    }
}
