package com.example.backorder.event;

import lombok.Getter;
import org.springframework.context.ApplicationEvent;

/**
 * Fired whenever an inventory sync detects new stock for a product.
 * Both the hourly scheduler and manual trigger publish this same event,
 * so the allocation job doesn't care how the sync was triggered.
 */
@Getter
public class InventoryRestockedEvent extends ApplicationEvent {

    private final Long productId;
    private final int previousStock;
    private final int newStock;

    public InventoryRestockedEvent(Object source, Long productId, int previousStock, int newStock) {
        super(source);
        this.productId = productId;
        this.previousStock = previousStock;
        this.newStock = newStock;
    }
}
