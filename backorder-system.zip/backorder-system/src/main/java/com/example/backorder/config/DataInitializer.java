package com.example.backorder.config;

import com.example.backorder.model.FulfillmentStrategyType;
import com.example.backorder.model.Product;
import com.example.backorder.repository.ProductRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

/**
 * Seeds a few sample products on startup so the API is immediately usable.
 * Remove or replace for production.
 */
@Component
@Slf4j
@RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner {

    private final ProductRepository productRepository;

    @Override
    public void run(String... args) {
        if (productRepository.count() > 0) return;

        productRepository.save(Product.builder()
                .sku("SKU-001")
                .name("Widget Pro")
                .availableStock(0)
                .allowsPartialFulfillment(false)
                .defaultStrategy(FulfillmentStrategyType.FIFO)
                .build());

        productRepository.save(Product.builder()
                .sku("SKU-002")
                .name("Gadget B2B")
                .availableStock(0)
                .allowsPartialFulfillment(true)
                .defaultStrategy(FulfillmentStrategyType.PARTIAL)
                .build());

        productRepository.save(Product.builder()
                .sku("SKU-003")
                .name("VIP Flash Item")
                .availableStock(0)
                .allowsPartialFulfillment(false)
                .defaultStrategy(FulfillmentStrategyType.PRIORITY)
                .build());

        log.info("Seeded 3 sample products (all at 0 stock to demonstrate backorder flow)");
    }
}
