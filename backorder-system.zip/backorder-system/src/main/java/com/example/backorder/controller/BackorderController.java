package com.example.backorder.controller;

import com.example.backorder.model.BackorderEntry;
import com.example.backorder.service.BackorderService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/backorders")
@RequiredArgsConstructor
public class BackorderController {

    private final BackorderService backorderService;

    /** View the current backorder queue for a product (sorted by priority + FIFO). */
    @GetMapping("/queue/{productId}")
    public ResponseEntity<List<BackorderEntry>> getQueue(@PathVariable Long productId) {
        return ResponseEntity.ok(backorderService.getQueueForProduct(productId));
    }
}
