package com.example.backorder.controller;

import com.example.backorder.controller.Dtos.CreateProductRequest;
import com.example.backorder.controller.Dtos.RestockRequest;
import com.example.backorder.model.Product;
import com.example.backorder.repository.ProductRepository;
import com.example.backorder.service.InventorySyncService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/inventory")
@RequiredArgsConstructor
public class InventoryController {

    private final InventorySyncService inventorySyncService;
    private final ProductRepository productRepository;

    /** Trigger a full inventory sync manually (all products). */
    @PostMapping("/sync")
    public ResponseEntity<Map<String, String>> syncAll() {
        inventorySyncService.manualSync();
        return ResponseEntity.ok(Map.of("status", "sync triggered"));
    }

    /** Trigger a targeted sync for a single product. */
    @PostMapping("/sync/{productId}")
    public ResponseEntity<Map<String, String>> syncProduct(@PathVariable Long productId) {
        inventorySyncService.syncProduct(productId);
        return ResponseEntity.ok(Map.of("status", "sync triggered", "productId", productId.toString()));
    }

    /**
     * Directly restock a product (simulates what the upstream sync would detect).
     * Useful for testing and for ops teams that know exact quantities to add.
     */
    @PostMapping("/restock")
    public ResponseEntity<Product> restock(@Valid @RequestBody RestockRequest request) {
        Product product = productRepository.findById(request.getProductId())
                .orElseThrow(() -> new IllegalArgumentException("Product not found"));

        int previous = product.getAvailableStock();
        product.setAvailableStock(request.getNewStock());
        productRepository.save(product);

        // Trigger allocation if stock increased
        if (request.getNewStock() > previous) {
            inventorySyncService.syncProduct(product.getId());
        }

        return ResponseEntity.ok(product);
    }

    /** Create a product (for bootstrapping / testing). */
    @PostMapping("/products")
    public ResponseEntity<Product> createProduct(@Valid @RequestBody CreateProductRequest request) {
        Product product = Product.builder()
                .sku(request.getSku())
                .name(request.getName())
                .availableStock(request.getInitialStock())
                .allowsPartialFulfillment(request.isAllowsPartialFulfillment())
                .defaultStrategy(request.getDefaultStrategy())
                .build();
        return ResponseEntity.ok(productRepository.save(product));
    }

    /** List all products with current stock levels. */
    @GetMapping("/products")
    public ResponseEntity<List<Product>> listProducts() {
        return ResponseEntity.ok(productRepository.findAll());
    }

    @GetMapping("/products/{id}")
    public ResponseEntity<Product> getProduct(@PathVariable Long id) {
        return productRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
}
