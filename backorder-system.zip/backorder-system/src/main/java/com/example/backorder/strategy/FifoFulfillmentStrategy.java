package com.example.backorder.strategy;

import com.example.backorder.model.BackorderEntry;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * Strict FIFO: fulfill orders in queue order, fully, until stock runs out.
 * If an order cannot be fully satisfied, stop — do not skip it to serve later orders.
 */
@Component("FIFO")
public class FifoFulfillmentStrategy implements FulfillmentStrategy {

    @Override
    public List<Allocation> allocate(List<BackorderEntry> queue, int availableStock) {
        List<Allocation> allocations = new ArrayList<>();

        for (BackorderEntry entry : queue) {
            if (availableStock <= 0) break;

            int needed = entry.quantityRemaining();
            if (availableStock >= needed) {
                allocations.add(new Allocation(entry, needed));
                availableStock -= needed;
            } else {
                // Can't fully fulfill — stop here to preserve FIFO fairness.
                // Only continue if this entry allows partial fulfillment.
                if (entry.isAllowsPartialFulfillment()) {
                    allocations.add(new Allocation(entry, availableStock));
                    availableStock = 0;
                } else {
                    break;
                }
            }
        }

        return allocations;
    }
}
