package com.example.backorder.config;

import com.example.backorder.model.FulfillmentStrategyType;
import com.example.backorder.strategy.FulfillmentStrategy;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * Resolves the correct FulfillmentStrategy bean by strategy type.
 * Each strategy is registered as a Spring bean named after its enum value (e.g. "FIFO").
 */
@Component
@RequiredArgsConstructor
public class StrategyResolver {

    // Spring injects all FulfillmentStrategy beans keyed by bean name
    private final Map<String, FulfillmentStrategy> strategies;

    public FulfillmentStrategy resolve(FulfillmentStrategyType type) {
        FulfillmentStrategy strategy = strategies.get(type.name());
        if (strategy == null) {
            throw new IllegalArgumentException("No strategy registered for type: " + type);
        }
        return strategy;
    }
}
