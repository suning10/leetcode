package com.example.backorder.model;

public enum FulfillmentStrategyType {
    FIFO,
    PRIORITY,
    PARTIAL
}
