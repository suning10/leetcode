package com.example.backorder.service;

import com.example.backorder.config.StrategyResolver;
import com.example.backorder.event.InventoryRestockedEvent;
import com.example.backorder.model.*;
import com.example.backorder.repository.BackorderEntryRepository;
import com.example.backorder.repository.OrderRepository;
import com.example.backorder.repository.ProductRepository;
import com.example.backorder.strategy.Allocation;
import com.example.backorder.strategy.FulfillmentStrategy;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Listens for InventoryRestockedEvent and runs the allocation loop.
 *
 * Concurrency safety:
 *   - ProductRepository.findByIdForUpdate() acquires a PESSIMISTIC_WRITE lock on the
 *     product row, so two concurrent sync triggers for the same product cannot
 *     double-allocate stock. The lock is held for the duration of the transaction.
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class BackorderAllocationJob {

    private final ProductRepository productRepository;
    private final BackorderEntryRepository backorderEntryRepository;
    private final OrderRepository orderRepository;
    private final StrategyResolver strategyResolver;
    private final NotificationService notificationService;

    /**
     * Entry point — triggered by both hourly sync and manual sync via Spring's
     * synchronous ApplicationEventPublisher.
     */
    @EventListener
    @Transactional
    public void onInventoryRestocked(InventoryRestockedEvent event) {
        log.info("Allocation triggered for productId={}, newStock={}",
                event.getProductId(), event.getNewStock());

        // 1. Acquire pessimistic lock on the product row
        Product product = productRepository.findByIdForUpdate(event.getProductId())
                .orElseThrow(() -> new IllegalStateException("Product not found: " + event.getProductId()));

        int availableStock = product.getAvailableStock();
        if (availableStock <= 0) {
            log.info("No available stock for productId={}, skipping allocation.", product.getId());
            return;
        }

        // 2. Fetch active backorder queue (sorted: priorityScore DESC, createdAt ASC)
        List<BackorderEntry> queue = backorderEntryRepository.findActiveQueueForProduct(product.getId());
        if (queue.isEmpty()) {
            log.info("No backorders waiting for productId={}", product.getId());
            return;
        }

        // 3. Resolve strategy — use product default; per-entry strategy override is applied
        //    inside each strategy's allocate() via entry.getFulfillmentStrategy() if needed.
        //    Here we use the product-level default to drive the overall loop behaviour.
        FulfillmentStrategy strategy = strategyResolver.resolve(product.getDefaultStrategy());

        // 4. Run allocation
        List<Allocation> allocations = strategy.allocate(queue, availableStock);

        // 5. Apply results atomically
        int totalAllocated = 0;
        for (Allocation allocation : allocations) {
            BackorderEntry entry = allocation.getEntry();
            int qty = allocation.getQuantity();

            entry.setQuantityFulfilled(entry.getQuantityFulfilled() + qty);
            totalAllocated += qty;

            boolean fullySatisfied = entry.quantityRemaining() == 0;
            entry.setStatus(fullySatisfied ? BackorderStatus.ALLOCATED : BackorderStatus.PARTIALLY_FULFILLED);

            backorderEntryRepository.save(entry);

            // Update parent order status
            updateOrderStatus(entry);

            // Send customer notification
            sendNotification(entry, qty, fullySatisfied);

            log.info("Allocated {} units to backorderEntry={} (order={}, product={}). Status: {}",
                    qty, entry.getId(), entry.getOrderId(), entry.getProductId(), entry.getStatus());
        }

        // 6. Deduct allocated stock from product
        product.setAvailableStock(availableStock - totalAllocated);
        productRepository.save(product);

        log.info("Allocation complete for productId={}. Allocated {} units. Remaining stock: {}",
                product.getId(), totalAllocated, product.getAvailableStock());
    }

    private void updateOrderStatus(BackorderEntry entry) {
        orderRepository.findById(entry.getOrderId()).ifPresent(order -> {
            List<BackorderEntry> allEntries = backorderEntryRepository.findByOrderId(order.getId());

            boolean allAllocated = allEntries.stream()
                    .allMatch(e -> e.getStatus() == BackorderStatus.ALLOCATED);
            boolean anyAllocated = allEntries.stream()
                    .anyMatch(e -> e.getStatus() == BackorderStatus.ALLOCATED
                                  || e.getStatus() == BackorderStatus.PARTIALLY_FULFILLED);

            if (allAllocated) {
                order.setStatus(OrderStatus.FULFILLED);
            } else if (anyAllocated) {
                order.setStatus(OrderStatus.PARTIALLY_FULFILLED);
            }
            // else stays BACKORDERED

            orderRepository.save(order);
        });
    }

    private void sendNotification(BackorderEntry entry, int qty, boolean fullySatisfied) {
        orderRepository.findById(entry.getOrderId()).ifPresent(order -> {
            if (fullySatisfied) {
                notificationService.notifyFulfilled(order, entry);
            } else {
                notificationService.notifyPartiallyFulfilled(order, entry, qty);
            }
        });
    }
}
