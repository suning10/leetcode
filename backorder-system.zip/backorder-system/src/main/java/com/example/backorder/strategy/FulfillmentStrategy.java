package com.example.backorder.strategy;

import com.example.backorder.model.BackorderEntry;
import java.util.List;

/**
 * Contract for all fulfillment strategies.
 * Each strategy receives the sorted queue and available stock,
 * and returns a list of allocation decisions.
 */
public interface FulfillmentStrategy {
    List<Allocation> allocate(List<BackorderEntry> queue, int availableStock);
}
