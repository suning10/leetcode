package com.example.backorder;

import com.example.backorder.model.*;
import com.example.backorder.repository.BackorderEntryRepository;
import com.example.backorder.repository.OrderRepository;
import com.example.backorder.repository.ProductRepository;
import com.example.backorder.service.BackorderService;
import com.example.backorder.service.InventorySyncService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@TestPropertySource(properties = {
    "app.inventory.sync-cron=0 0 3 31 2 *",  // never fires in tests
    "spring.data.redis.host=localhost",
    "spring.autoconfigure.exclude=org.springframework.boot.autoconfigure.data.redis.RedisAutoConfiguration," +
            "org.springframework.boot.autoconfigure.data.redis.RedisRepositoriesAutoConfiguration"
})
class BackorderAllocationJobTest {

    @Autowired ProductRepository productRepository;
    @Autowired OrderRepository orderRepository;
    @Autowired BackorderEntryRepository backorderEntryRepository;
    @Autowired BackorderService backorderService;
    @Autowired InventorySyncService inventorySyncService;

    private Product product;

    @BeforeEach
    void setup() {
        backorderEntryRepository.deleteAll();
        orderRepository.deleteAll();
        productRepository.deleteAll();

        product = productRepository.save(Product.builder()
                .sku("TEST-001")
                .name("Test Product")
                .availableStock(0)
                .allowsPartialFulfillment(false)
                .defaultStrategy(FulfillmentStrategyType.FIFO)
                .build());
    }

    @Test
    void fifo_fullyFulfillsOrdersInOrder_whenEnoughStock() {
        // Place 3 backorders totalling 9 units
        Order o1 = backorderService.placeOrder("customer-1", product.getId(), 3, null, 0, false);
        Order o2 = backorderService.placeOrder("customer-2", product.getId(), 3, null, 0, false);
        Order o3 = backorderService.placeOrder("customer-3", product.getId(), 3, null, 0, false);

        assertThat(o1.getStatus()).isEqualTo(OrderStatus.BACKORDERED);

        // Restock 9 units and trigger sync
        product.setAvailableStock(9);
        productRepository.save(product);
        inventorySyncService.syncProduct(product.getId());

        assertOrderStatus(o1.getId(), OrderStatus.FULFILLED);
        assertOrderStatus(o2.getId(), OrderStatus.FULFILLED);
        assertOrderStatus(o3.getId(), OrderStatus.FULFILLED);

        Product updated = productRepository.findById(product.getId()).orElseThrow();
        assertThat(updated.getAvailableStock()).isEqualTo(0);
    }

    @Test
    void fifo_stopsAtFirstUnserviceableOrder_whenInsufficientStock() {
        Order o1 = backorderService.placeOrder("customer-1", product.getId(), 5, null, 0, false);
        Order o2 = backorderService.placeOrder("customer-2", product.getId(), 3, null, 0, false);

        // Only 4 units arrive — enough for o1? No (needs 5). Should stop, not skip to o2.
        product.setAvailableStock(4);
        productRepository.save(product);
        inventorySyncService.syncProduct(product.getId());

        assertOrderStatus(o1.getId(), OrderStatus.BACKORDERED);  // not served
        assertOrderStatus(o2.getId(), OrderStatus.BACKORDERED);  // not skipped to
        assertThat(productRepository.findById(product.getId()).orElseThrow().getAvailableStock()).isEqualTo(4);
    }

    @Test
    void priority_servesHigherPriorityFirst() {
        Product vipProduct = productRepository.save(Product.builder()
                .sku("VIP-001").name("VIP Item").availableStock(0)
                .allowsPartialFulfillment(false)
                .defaultStrategy(FulfillmentStrategyType.PRIORITY).build());

        Order standard = backorderService.placeOrder("customer-standard", vipProduct.getId(), 3,
                FulfillmentStrategyType.PRIORITY, 0, false);
        Order vip = backorderService.placeOrder("customer-vip", vipProduct.getId(), 3,
                FulfillmentStrategyType.PRIORITY, 100, false);

        // Only 3 units — should go to VIP (higher priority score), not standard (placed first)
        vipProduct.setAvailableStock(3);
        productRepository.save(vipProduct);
        inventorySyncService.syncProduct(vipProduct.getId());

        assertOrderStatus(vip.getId(), OrderStatus.FULFILLED);
        assertOrderStatus(standard.getId(), OrderStatus.BACKORDERED);
    }

    @Test
    void cancelOrder_releasesBackorderEntry() {
        Order order = backorderService.placeOrder("customer-1", product.getId(), 5, null, 0, false);
        assertThat(order.getStatus()).isEqualTo(OrderStatus.BACKORDERED);

        backorderService.cancelOrder(order.getId());

        Order cancelled = orderRepository.findById(order.getId()).orElseThrow();
        assertThat(cancelled.getStatus()).isEqualTo(OrderStatus.CANCELLED);

        List<BackorderEntry> entries = backorderEntryRepository.findByOrderId(order.getId());
        assertThat(entries).allMatch(e -> e.getStatus() == BackorderStatus.CANCELLED);
    }

    private void assertOrderStatus(Long orderId, OrderStatus expected) {
        Order o = orderRepository.findById(orderId).orElseThrow();
        assertThat(o.getStatus())
                .as("Order %d should be %s", orderId, expected)
                .isEqualTo(expected);
    }
}
