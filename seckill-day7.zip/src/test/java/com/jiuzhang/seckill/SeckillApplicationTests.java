package com.jiuzhang.seckill;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SeckillApplicationTests {

  @Test
  void contextLoads() {
    System.out.println("Hello, test!");
  }

}
